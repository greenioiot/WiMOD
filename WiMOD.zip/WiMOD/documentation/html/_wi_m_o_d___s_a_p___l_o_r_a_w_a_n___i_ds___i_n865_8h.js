var _wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h =
[
    [ "IS_LORAWAN_CH_IN2", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a2e2e0bdc25501df7518f7267d24c49aa", null ],
    [ "LORAWAN_CH_IN2_865_062_5_MHZ", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#aa63ff368215ab9807bdd7ef608adfa00", null ],
    [ "LORAWAN_CH_IN2_865_402_5_MHZ", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#ad2aff47d257b1e1dfef32b860bda7b85", null ],
    [ "LORAWAN_CH_IN2_865_985_MHZ", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a63d1886b63c421886f8677d2fca37507", null ],
    [ "LORAWAN_CH_IN2_866_550_MHZ", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a436878b359b308f4b862dcc3ed68457d", null ],
    [ "TLoRaWAN_Channel_India", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#ac5a382ccdb107dc1901759704fdc8cd3", null ],
    [ "TLoRaWAN_Channel_IndiaTwo", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a4844d07b52aca41e3f6cff5253f66305", null ],
    [ "TLoRaWANDataRateIN865", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#ae885a1053cfaaf5567a61af9a683845a", null ],
    [ "TLoRaWAN_Channel_India", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a5e9d629238e4ccdfa6b789adc58dd7a2", [
      [ "LoRaWAN_Channel_India_865_062_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a5e9d629238e4ccdfa6b789adc58dd7a2a9c97f79c76b4ce7f5076723b608de006", null ],
      [ "LoRaWAN_Channel_India_865_402_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a5e9d629238e4ccdfa6b789adc58dd7a2a812739d5d9a62e4b743f275538ce3448", null ],
      [ "LoRaWAN_Channel_India_865_985_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a5e9d629238e4ccdfa6b789adc58dd7a2a64da593f3ccce20d5aacca106d2cd52a", null ],
      [ "LoRaWAN_Channel_India_866_550_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a5e9d629238e4ccdfa6b789adc58dd7a2aed7f2a06f3a5e9ad8790bc1c0d33a594", null ]
    ] ],
    [ "TLoRaWAN_Channel_IndiaTwo", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a6ef10bbbac1cd76b7171243a38cd1ae5", [
      [ "LoRaWAN_Channel_India2_865_062_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a6ef10bbbac1cd76b7171243a38cd1ae5a649a98e3d078ffc388a1328d91add4c0", null ],
      [ "LoRaWAN_Channel_India2_865_402_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a6ef10bbbac1cd76b7171243a38cd1ae5a36a51816b066b677e9bbaafe91066e16", null ],
      [ "LoRaWAN_Channel_India2_865_985_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a6ef10bbbac1cd76b7171243a38cd1ae5ac561c3fcf174473084cf030c9f9107fd", null ],
      [ "LoRaWAN_Channel_India2_866_550_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a6ef10bbbac1cd76b7171243a38cd1ae5a9f2a8eff7a1b1c88c8b86cecc2bcb1bb", null ]
    ] ],
    [ "TLoRaWANDataRateIN865", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283b", [
      [ "LoRaWAN_DataRate_IN865_LoRa_SF12_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283ba23ee031b31e4205eae9b7611f4aa3050", null ],
      [ "LoRaWAN_DataRate_IN865_LoRa_SF11_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283baa42e35a883f5ff95ffbb2647ba7d2e64", null ],
      [ "LoRaWAN_DataRate_IN865_LoRa_SF10_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283ba3f288f2045e9cef4c1650aae52c0f853", null ],
      [ "LoRaWAN_DataRate_IN865_LoRa_SF9_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283bad853f358dc4e9e4b884a1a428afcf7ef", null ],
      [ "LoRaWAN_DataRate_IN865_LoRa_SF8_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283ba9c9c6af828b3d959471a1c34570bf86d", null ],
      [ "LoRaWAN_DataRate_IN865_LoRa_SF7_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283baacadcc8c051f3c3b01b0c2d8babb8573", null ],
      [ "LoRaWAN_DataRate_IN865_LoRa_FSK", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_n865_8h.html#a3a71d60d950667eb0aab6d146419283bab35cb7b107f9c416107cc4314d37c908", null ]
    ] ]
];