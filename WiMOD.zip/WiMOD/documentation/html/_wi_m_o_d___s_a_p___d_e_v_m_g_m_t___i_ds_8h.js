var _wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h =
[
    [ "TWiMODLR_DevMgmt_DevInfo", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info" ],
    [ "TWiMODLR_DevMgmt_FwInfo", "struct_t_wi_m_o_d_l_r___dev_mgmt___fw_info.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___fw_info" ],
    [ "TWiMODLR_DevMgmt_SystemStatus", "struct_t_wi_m_o_d_l_r___dev_mgmt___system_status.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___system_status" ],
    [ "TWiMODLR_DevMgmt_RadioConfig", "struct_t_wi_m_o_d_l_r___dev_mgmt___radio_config.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___radio_config" ],
    [ "TWiMODLR_DevMgmt_RtcAlarm", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm" ],
    [ "DEVMGMT_SAP_ID", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9267c3b7bbb19c1c5e08bf7024247b3c", null ],
    [ "WIMOD_RTC_GET_DAYS", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a22c10bca2b48812850e6bb074ade184e", null ],
    [ "WIMOD_RTC_GET_HOURS", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a0a289b8ec8ccbba4b02c528ae6a5a667", null ],
    [ "WIMOD_RTC_GET_MINUTES", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a3b08422d29d39323750b25756f73049a", null ],
    [ "WIMOD_RTC_GET_MONTHS", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a87a9bd6a2808868f8623fd4b5ba84be4", null ],
    [ "WIMOD_RTC_GET_SECONDS", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a73f287e9d2065c7e5f0bb8199cd1d48c", null ],
    [ "WIMOD_RTC_GET_YEARS", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ac3b6cf2e1f44de992d1d4c96dda171b3", null ],
    [ "WIMOD_RTC_MAKE_DATETIME_U32", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9a32bd2a6285431b3a67dc6dde1fb14c", null ],
    [ "WiMOD_RTC_YEAR_OFFSET", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a4327875a7152f383df46f35b95c1fef9", null ],
    [ "TRadioCfg_ErrorCoding", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a6cb429a6458d8efa02a10198c3484f09", null ],
    [ "TRadioCfg_FskDatarate", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ac1f19d9eabdd30d81ab5dee360f0c123", null ],
    [ "TRadioCfg_LoRaBandwidth", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#adf793a3e28c6316317361247014a58f6", null ],
    [ "TRadioCfg_LoRaSpreadingFactor", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a3b3818d21222bf14c3c41af23b9cd1d2", null ],
    [ "TRadioCfg_Modulation", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ae3d4bbd9f613a3730f0ab43895229c09", null ],
    [ "TRadioCfg_PowerLevel", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a2b36aaf15735fa5a0b4baa48ff0449b5", null ],
    [ "TRadioCfg_PowerSavingMode", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a6acfd8887b1ac6e78259aadf90473f62", null ],
    [ "TRadioCfg_RadioMode", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a39191724fd5f851a191fd3621b33e734", null ],
    [ "TRadioCfg_RxControl", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a58d5cd8fe1107a31c3ece6bd0b6ef8d7", null ],
    [ "TWiMOD_ModuleType", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a79da46de65d16f236503dde46b00e5a3", null ],
    [ "TWiMOD_OperationMode", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a204b4f691f2b7f3fb8ca8bef7341a5c2", null ],
    [ "TWiMOD_RtcAlarmStatus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a8acd02c2e94f09d9871d80d2b2fa0db6", null ],
    [ "TWiMOD_RtcAlarmType", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a190a1af4ef223cd130ad94b88390f07b", null ],
    [ "TWiMODLR_DevMgmt_DevInfo", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#adfffd40b98b8cf1e405acf04c32d57e5", null ],
    [ "TWiMODLR_DevMgmt_FwInfo", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aee81e08aa564b78e5b3b53437d476ff8", null ],
    [ "TWiMODLR_DevMgmt_RadioConfig", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a1b17a523002695d071618ed8b6e07eeb", null ],
    [ "TWiMODLR_DevMgmt_RtcAlarm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aedb5338cac5f0c80df5a35e2fb4d5d2a", null ],
    [ "TWiMODLR_DevMgmt_SystemStatus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aa498e3099d9adb103151d91aa8d89bd6", null ],
    [ "TRadioCdf_TxPowerLevel", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046", [
      [ "TxPowerLevel_5_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046ae9e14334682bf49d721562983030fe3b", null ],
      [ "TxPowerLevel_6_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046ae94160f6decad870a0dc0031f4760595", null ],
      [ "TxPowerLevel_7_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046af436bde691698b56cf942b77f655ee6b", null ],
      [ "TxPowerLevel_8_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a1f005c48d514195418d41d3a656aea77", null ],
      [ "TxPowerLevel_9_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a2a911b1c5019cb8c267e251f8fdd5210", null ],
      [ "TxPowerLevel_10_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a8ee4f003564e36f44cfb9c3511b4ee25", null ],
      [ "TxPowerLevel_11_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046aab8f951cca5297eabe8f58c6144fc41e", null ],
      [ "TxPowerLevel_12_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a1bdba6a569acb227969ae2c8ab7316cb", null ],
      [ "TxPowerLevel_13_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a110bddb388ac3b0e8187620d2d2b7474", null ],
      [ "TxPowerLevel_14_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046aaefdd752ad455d6beef8b269e2334f52", null ],
      [ "TxPowerLevel_15_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046ad55eca6752d1c9bc750466b01694e148", null ],
      [ "TxPowerLevel_16_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046ae29426d28ab27e9b422266310182ba37", null ],
      [ "TxPowerLevel_17_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a69c265c8cc047e20177152d8c8b8f7ad", null ],
      [ "TxPowerLevel_18_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a5fd499ed1fd2b9666526c3e958852054", null ],
      [ "TxPowerLevel_19_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046a34583d59869bd055a6e6947cae757f74", null ],
      [ "TxPowerLevel_20_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a69062a5ef3febfaf55f637aaa639e046af50ce21735837f890250c484c3631fdd", null ]
    ] ],
    [ "TRadioCfg_ErrorCoding", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7e3e02a3216a83babfe8418087a18a51", [
      [ "ErrorCoding0_4_5", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7e3e02a3216a83babfe8418087a18a51a424280f57c496dcda5cbeeee347981b0", null ],
      [ "ErrorCoding1_4_5", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7e3e02a3216a83babfe8418087a18a51ae5e3b31350a9c236d5fdf6768032d37a", null ],
      [ "ErrorCoding2_4_6", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7e3e02a3216a83babfe8418087a18a51a8e496ab1d18c1ea6c04c6c4b9c97ceaf", null ],
      [ "ErrorCoding3_4_7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7e3e02a3216a83babfe8418087a18a51a02da8c08979ef08b6ff21d40334242c3", null ],
      [ "ErrorCoding4_4_8", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7e3e02a3216a83babfe8418087a18a51aa51f45ac7acb78794db75d6c6e968af8", null ]
    ] ],
    [ "TRadioCfg_FskDatarate", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a66f7c8731b2d713af9fcf086284fa59f", [
      [ "FskDatarate_50kbps", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a66f7c8731b2d713af9fcf086284fa59fabe7eaa1c61e7fd67a30201f7b3c67377", null ],
      [ "FskDatarate_100kbps", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a66f7c8731b2d713af9fcf086284fa59fad612e628f99276bd6aa2967d74890c5e", null ],
      [ "FskDatarate_250kbps", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a66f7c8731b2d713af9fcf086284fa59fa83d614b09485627d9ccdb03a459017a0", null ]
    ] ],
    [ "TRadioCfg_LoRaBandwidth", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9d75afd951da6be11dfb2101d3e679e8", [
      [ "LoRaBandwith_125kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9d75afd951da6be11dfb2101d3e679e8acc7dc0b7b2dbd840781b3d5a405eed8d", null ],
      [ "LoRaBandwith_250kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9d75afd951da6be11dfb2101d3e679e8aa334b807db288eb0289fb4d953508752", null ],
      [ "LoRaBandwith_500kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9d75afd951da6be11dfb2101d3e679e8adf133e82b60c831accb04ffd01c81858", null ]
    ] ],
    [ "TRadioCfg_LoRaSpreadingFactor", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82", [
      [ "LoRa0_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82ae46cad33f04d3abdc3a2bf91b7327f2d", null ],
      [ "LoRa1_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a67ec3dd226585ddc1be9bfa9c9ab9fc0", null ],
      [ "LoRa2_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82acd69a8a7e67260f272fc7fd8c5067808", null ],
      [ "LoRa3_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a452d2207a02e2db268d9f6055a9dda6c", null ],
      [ "LoRa4_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a5e70a0a75017caa2db12d7648323ac97", null ],
      [ "LoRa5_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82afe3c2f784139676828d40d40703630d4", null ],
      [ "LoRa6_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a7c74ac88dc278a38a732b07ff6db0f4a", null ],
      [ "LoRa7_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a2aace81a2081b78ed4cf6fd03d4561c5", null ],
      [ "LoRa8_SF8", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a9e527b85018aae1095c4fbb74228c0f5", null ],
      [ "LoRa9_SF9", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a85a842ee10c2818dc067f44254607c21", null ],
      [ "LoRa10_SF10", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82aba0db23319f745c6d1ef771cf8a76218", null ],
      [ "LoRa11_SF11", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82aeb8a007ac512e0cffef8ce1894e6673c", null ],
      [ "LoRa12_S12", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#aabacfa9be62b266b9a21560bb7e25d82a236aa57e45a4b3dece76cb6fcacad64f", null ]
    ] ],
    [ "TRadioCfg_Modulation", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a50aeb97f78ab51ba61757fd0cc8e6eff", [
      [ "Modulation_LoRa", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a50aeb97f78ab51ba61757fd0cc8e6effa912a4dde2b935e298f000c92dffceb75", null ],
      [ "Modulation_FSK", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a50aeb97f78ab51ba61757fd0cc8e6effa641fb94e0b96248229873c0047e7f0f2", null ]
    ] ],
    [ "TRadioCfg_PowerSavingMode", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7dcc883674564a7f372761892293b0b5", [
      [ "PowerSaving_Off", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7dcc883674564a7f372761892293b0b5a17d7e2c57a3c1fb3715c42c1baf34dd5", null ],
      [ "PowerSaving_On", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7dcc883674564a7f372761892293b0b5a826e418b06229bb02f1d43b2a02fc465", null ]
    ] ],
    [ "TRadioCfg_RadioMode", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ab714b5b1dc2a2035836e1d3e9c722e54", [
      [ "RadioMode_Standard", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ab714b5b1dc2a2035836e1d3e9c722e54a114f142b95bcde9be70d485fe1e319a3", null ],
      [ "RadioMode_Echo", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ab714b5b1dc2a2035836e1d3e9c722e54a1326f80d22fbeae3587cb7453881e1ed", null ],
      [ "RadioMode_Sniffer", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ab714b5b1dc2a2035836e1d3e9c722e54adf9809c80c945a645198cc063ddad4e0", null ]
    ] ],
    [ "TRadioCfg_RxControl", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a1fa9f68738428e61d8db8887a085b2f2", [
      [ "RxCtrl_Receiver_Off", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a1fa9f68738428e61d8db8887a085b2f2ad54beb6a1586d4e2d792c2ab720c33ff", null ],
      [ "RxCtrl_Receiver_AlwaysOn", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a1fa9f68738428e61d8db8887a085b2f2a00691aac0d263ef7570ce4eb48d51fbd", null ],
      [ "RxCtrl_Receiver_RxWindowed", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a1fa9f68738428e61d8db8887a085b2f2abed8b376ffc4e6e494ed7a8472a14c11", null ]
    ] ],
    [ "TWiMOD_ModuleType", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ac7060c00e952ecb28d8b0019eeb315c4", [
      [ "ModuleType_iM880B", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#ac7060c00e952ecb28d8b0019eeb315c4a0661f615773bd029dfc11b421400fe93", null ]
    ] ],
    [ "TWiMOD_OperationMode", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7bd4881a1bcee8a0cd481bf60eae7f0c", [
      [ "OperationMode_Application", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7bd4881a1bcee8a0cd481bf60eae7f0caf159836af807cac72fc1fc93443baa15", null ],
      [ "OperationMode_Test", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7bd4881a1bcee8a0cd481bf60eae7f0cab4e0cf5e20f3c86c287ea46cd3d93a43", null ],
      [ "OperationMode_Reserved2", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7bd4881a1bcee8a0cd481bf60eae7f0ca623500a80515be1b46674e52d3246c9e", null ],
      [ "OperationMode_Customer", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7bd4881a1bcee8a0cd481bf60eae7f0cac518bc0983ff49ab11c52fac15edc1bd", null ]
    ] ],
    [ "TWiMOD_RtcAlarmStatus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a78123ade3cf5fe84d0d078cd411b1846", [
      [ "RTC_Alarm_No_Alarm_Set", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a78123ade3cf5fe84d0d078cd411b1846a8cad0a432495b1e0d97193453c840ba1", null ],
      [ "RTC_Alarm_Alarm_Set", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a78123ade3cf5fe84d0d078cd411b1846a85de5463072c7c566ef76ad2c284fb5f", null ]
    ] ],
    [ "TWiMOD_RtcAlarmType", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9a8b2ec97b8528f4b93133485a404e4b", [
      [ "RTC_Alarm_Single", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9a8b2ec97b8528f4b93133485a404e4ba820dc39a2d9ebe6a1a378df8ed9ed428", null ],
      [ "RTC_Alarm_DailyRepeated", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a9a8b2ec97b8528f4b93133485a404e4ba43d1fe4f9f7afbe4e0b1fc495915a5a3", null ]
    ] ]
];