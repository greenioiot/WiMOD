var searchData=
[
  ['powersaving_5foff',['PowerSaving_Off',['../_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7dcc883674564a7f372761892293b0b5a17d7e2c57a3c1fb3715c42c1baf34dd5',1,'WiMOD_SAP_DEVMGMT_IDs.h']]],
  ['powersaving_5fon',['PowerSaving_On',['../_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___i_ds_8h.html#a7dcc883674564a7f372761892293b0b5a826e418b06229bb02f1d43b2a02fc465',1,'WiMOD_SAP_DEVMGMT_IDs.h']]]
];
