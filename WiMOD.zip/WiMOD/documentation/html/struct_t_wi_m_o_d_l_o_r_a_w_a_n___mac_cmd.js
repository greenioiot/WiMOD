var struct_t_wi_m_o_d_l_o_r_a_w_a_n___mac_cmd =
[
    [ "DataServiceType", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___mac_cmd.html#a10827f06fcab300a4873b9b0d63d5f2e", null ],
    [ "Length", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___mac_cmd.html#a1e69918435f33212e9e3e0a9be3f2df2", null ],
    [ "MacCmdID", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___mac_cmd.html#a444dcc116873c33830c154956fd24270", null ],
    [ "Payload", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___mac_cmd.html#a672eb2d3c34e2bf5da60188d5803c625", null ]
];