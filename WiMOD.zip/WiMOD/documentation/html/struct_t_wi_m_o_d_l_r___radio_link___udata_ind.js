var struct_t_wi_m_o_d_l_r___radio_link___udata_ind =
[
    [ "AirTime", "struct_t_wi_m_o_d_l_r___radio_link___udata_ind.html#a21a456383e5eafa67283032f00004920", null ],
    [ "Status", "struct_t_wi_m_o_d_l_r___radio_link___udata_ind.html#a4cbb85e7acc8ff081759b52e59c32a32", null ],
    [ "TxEventCounter", "struct_t_wi_m_o_d_l_r___radio_link___udata_ind.html#aacfdf7cb0c1ab8b6e08fc197fb400c82", null ]
];