var _wi_m_o_d_l_r___b_a_s_e_8h =
[
    [ "WiMODLRBASE", "class_wi_m_o_d_l_r_b_a_s_e.html", "class_wi_m_o_d_l_r_b_a_s_e" ],
    [ "TDataLinkRxUDataIndClient", "_wi_m_o_d_l_r___b_a_s_e_8h.html#a4818f1e49eff4377a24ed05fa4a20f06", null ],
    [ "TDataLinkSendUdataIndClient", "_wi_m_o_d_l_r___b_a_s_e_8h.html#a311e84324cbd1f595e9cd8d7e7df15a9", null ]
];