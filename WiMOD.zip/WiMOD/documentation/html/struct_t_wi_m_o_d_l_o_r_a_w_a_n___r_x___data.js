var struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data =
[
    [ "ChannelIndex", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#a9965769f33b15610bd58170e3affdf90", null ],
    [ "DataRateIndex", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#af875561d78aac034d73b5fb90dd22f3f", null ],
    [ "Length", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#a846fc950eb7bb530d7f3116705b24bce", null ],
    [ "OptionalInfoAvaiable", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#aa52ab7cbdc3e54ada395f648fd9a0192", null ],
    [ "Payload", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#ac47759e98f242499fc5f136353828852", null ],
    [ "Port", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#a94521c919126d74d9091a54f7f03dca6", null ],
    [ "RSSI", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#a5eab4d5eb2f1bc9400c981c707539e48", null ],
    [ "RxSlot", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#a7ba58587664917cb52d0bf6c7e99a90f", null ],
    [ "SNR", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#ac910f33490914e55605949ca5ec6a251", null ],
    [ "StatusFormat", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___data.html#a32ec92beb60f68480f70180ac4b99e09", null ]
];