var _c_r_c16_8h =
[
    [ "CRC16_GOOD_VALUE", "_c_r_c16_8h.html#ab565fe4602fff2131dde7b1de0d4133c", null ],
    [ "CRC16_INIT_VALUE", "_c_r_c16_8h.html#aa8b0311c2e6302e6f540a7129376c442", null ],
    [ "CRC16_POLYNOM", "_c_r_c16_8h.html#a83009878e695ffa15091e426ef55b045", null ],
    [ "CRC16_Calc", "_c_r_c16_8h.html#a93a1b56a0fda275037fcbd50937e3cde", null ],
    [ "CRC16_Check", "_c_r_c16_8h.html#aacacda4793c542839f3663904dd8b29f", null ]
];