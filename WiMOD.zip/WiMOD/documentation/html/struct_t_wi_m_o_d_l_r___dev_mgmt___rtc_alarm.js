var struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm =
[
    [ "AlarmStatus", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm.html#abbac3c3978d333eea4c762c7ba467e95", null ],
    [ "Hour", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm.html#af3299f3a61a0638e93aaff136adbcb80", null ],
    [ "Minutes", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm.html#aa224b5cdc27f4d01c506c6ec4bd608d0", null ],
    [ "Options", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm.html#a58716ddf8405b1e462b6728dc6f0b0c5", null ],
    [ "Seconds", "struct_t_wi_m_o_d_l_r___dev_mgmt___rtc_alarm.html#a1e80dc8f33562b318c59282942ccc827", null ]
];